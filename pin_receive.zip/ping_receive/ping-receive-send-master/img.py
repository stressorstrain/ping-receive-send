import Image

Image.open(upda.ico)
Img.show()
