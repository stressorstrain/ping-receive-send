import subprocess


def jstping():
    
    command0 = "ping -c 2 ut.sportsontheweb.net"
    print(command0)
    process = (subprocess.call(command0, shell=True))

    if process == 0:
        return True
    else:
        return False


if __name__ == '__main__':
    jstping()

