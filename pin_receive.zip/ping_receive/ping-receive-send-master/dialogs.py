import tkinter as tk
from tkinter import messagebox


def upd_conf():
    def topl():
        root = tk.Tk()
        root.geometry('200x100')
        root.config(bg='black')

        #return bvar

        def n_answr():
             bvar = str("1")
             print(bvar)


        def y_answr():
            bvar = str("2")

    if bvar == 0:
        return False
    else:
        if bvar == 2:
            return True

        frame1 = tk.Frame(root, bg='black',  height='100', width='200')
        label1 = tk.Label(frame1,  bg='black',  fg='white', text='Updates available'+"\n"+"Should I retrieve them?")
        bt1 = tk.Button(frame1, bg='black', fg='white', text='sure!', activebackground='green', command=y_answr)
        bt2 = tk.Button(frame1, bg='black', fg='white', text='nope!', activebackground='red', command=n_answr)

        frame1.grid()
        label1.grid(column=0, row=0,  pady=(5, 10), padx=(30, 0))
        bt1.grid(column=0, row=1, padx=(0, 15,))
        bt2.grid(column=0, row=1,   padx=(110, 0))

        #result = messagebox.askquestion("Information", "There are new files"+"\n"+"Should I retrieve them?")

        root.mainloop()

    print(topl())

upd_conf()



