#!/usr/bin/python
# -*- coding: iso-8859-1 -*-


import tkinter as tk
from pingin import jstping
from ftpong import lag, listing
from ftplib import FTP


class Window(tk.Tk):
    def __init__(self, parent):
        tk.Tk.__init__(self, parent,)
        super().__init__()
        self.parent = parent
        # self.initialize()

    # def initialize(self):
     self.grid()
    # self..v1 = tk.IntVar(value=1)
    #  self.v1 = Tk.StringVar(value=1)
    button1 = tk.Button(self,  text="Check for Updates", command=self.filing)
    button1.grid(column=0, row=4, sticky='W')
    l0 = tk.Label(self, text="Server Status", fg='white', bg='black')
    l0.grid(column=0, row=0, sticky='W')
    self.l1 = tk.Label(self, text="Host Status", fg='white', bg='black')
    self.l1.grid(column=0, row=2, sticky='W')
   #  self.colorvar= tk.configure()
    self.rd0 = tk.Radiobutton(self, text=None, bg='black', selectcolor='red')
    self.rd0.grid(column=1, row=0, sticky='W')
    # self.rd0.deselect()
    self.rd1 = tk.Radiobutton(self, text=None, bg='black', selectcolor='red')
    self.rd1.grid(column=1, row=2, sticky='W')
    # self.rd1.deselect()
        # ping_select(self)
    rd2 = tk.Radiobutton(self, text=None,  bg='black', selectcolor='black')
    rd2.grid(column=1, row=3, sticky='W')
        


        # label = Tkinter.Label(self, anchor="w", fg="white", bg="black")
        # label.grid(column=0,row=1,columnspan=2,sticky="EW")

   self.grid_columnconfigure(0, weight=1)
   self.resizable(True, False)
   self.select()

    def filing(self):
        status = lag()
        print(status)
        if status:
            print("new files!")
            self.rd3.configure(selectcolor="green")
            self.rd3.select()
        else:
            if not status:
                print("nothing")
                self.rd2.configure(selectcolor="blue")
                self.rd2.select()

    def select(self,):
            
        # self.rd1.configure(selectcolor='red')
        server_stats = jstping()
        if server_stats:
            self. rd0.configure(selectcolor='green')
            self.rd0.select()
        else:
            self.rd0.select()    
     

def center_window(width=300, height=200):
    # get screen width and height
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()

    # calculate position x and y coordinates
    x = (screen_width/2) - (width/2)
    y = (screen_height/2) - (height/2)
    root.geometry('%dx%d+%d+%d' % (width, height, x, y))


if __name__ == "__main__":
    # var = IntVar()
    root = Window(None)
    root.title('Music Box')
    root.geometry("250x150")
    root.configure(bg='black')
    # center_window(600,400)
    root.mainloop()
