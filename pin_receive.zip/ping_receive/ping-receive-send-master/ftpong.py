from ftplib import FTP
# from dialogs import upd_conf
from dialogx import tester




def lag():
    ftp = FTP("ut.sportsontheweb.net")
    ftp.login(user='2049465', passwd='Access01!')

    return listing(ftp)

    # uploading(ftp)


def listing(ftp):
    def current_files():
        files = []
        
        ftp.cwd('ut.sportsontheweb.net/guiba')
        ftp.dir(files.append)
        # outfile = open("files_list", "w")
        # print(files)
        count0 = 0

        for i in files:
            # outfile.write(i+"\n")
            count0 += 1
            
        print(count0)
        return old_files(count0, files)
        
    def old_files(count0, files):
        count1 = 0
        readfile = open("files_list", "r")
        for i in readfile:
            count1 += 1 
        print(count1)
        if count1 == count0:
            return False
        else:
            if count1 != count0:
                status = tester()
                return(status)
                # outfile1 = open("files_list", "w")
                # for i in files:
                # outfile1.write(i+"\n")

    return current_files()

# def uploading(ftp):
    # res = ftp.storlines("STOR " + olar.txt, fp)


if __name__ == '__main__':
    lag()
    # listing()
    # ownload()
    # upload()
