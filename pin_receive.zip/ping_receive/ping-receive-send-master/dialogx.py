import tkinter as tk

def stat():
    status = None
    print(tester())

def tester():
    root = tk.Tk()
    root.geometry('200x100')
    root.config(bg='black')


    def returner():
         return False

    bt1 = tk.Button(root, text="ok", command=returner)
    bt1.grid()



    root.mainloop()
stat()