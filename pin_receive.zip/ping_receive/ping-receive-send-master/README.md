# ping-receive-send
Ping the server, and upload/dowload files
