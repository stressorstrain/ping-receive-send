import tkinter as tk
from pingin import jstping
from PIL import ImageTk, Image
from ftpong import lag, listing


class Root(tk.Tk):
    def __init__(self):
        super().__init__()

        self.root_canvas = tk.Canvas(self, bg='black')
        self.root_frame = tk.Frame(self.root_canvas, bg='black')
        self.label0 = tk.Frame(self.root_frame, borderwidth=0,   bg='black')
        self.label1 = tk.Frame(self.root_frame, borderwidth=0,  bg='black')
        self.text_frame = tk.Frame(self.root_frame, borderwidth=0)

        path = "/home/guibax/Programs/ping_receive/ping-receive-send-master/upda.ico"
        self.up_img = ImageTk.PhotoImage(file=path)

        self.title("Music Box")
        self.geometry("500x600")

        self.root_txt = tk.Text(self.text_frame, bg='white', fg='black', width=25, height=40)
        self.lb0 = tk.Label(self.label0, text="Server Status", fg='white', bg='black')
        self.lb1 = tk.Label(self.label1, text='File Manager', fg='white', bg='black')
        self.lb2 = tk.Label(self.label0, text='Host Status', fg='white', bg='black')
        self.rd0 = tk.Radiobutton(self.label0, text=None, bg='black', selectcolor='red', borderwidth=0,
                                  highlightbackground='black')
        self.rd1 = tk.Radiobutton(self.label0, text=None,  bg='black', selectcolor='red', borderwidth=0,
                                  highlightbackground='black')

        self.bt1 = tk.Button(self.label0, text="Check for Updates",  command=self.check_updates)
        self.bt2 = tk.Button(self.label0, image=self.up_img, text=None, height=10,  width=10, bg="black",
                             command=self.check_server, relief="flat", highlightbackground='black')
        self.bt3 = tk.Button(self.label0, image=self.up_img, text=None, height=10,  width=10, bg="black",
                             relief="flat", highlightbackground='black')

        # self.up_lb = tk.Label(self.label0, image=up_ic, bg="red")

        self.root_canvas.grid()
        self.root_frame.grid()
        self.label0.grid()
        self.label1.grid(column=3, row=0)
        self.text_frame.grid(row=6, column=2, pady=(0, 5))
        self.lb0.grid(row=0, column=0)
        self.lb1.grid(row=0, column=3, padx=(0, 50))
        self.lb2.grid(row=4, column=0)
        self.rd0.grid(column=2, row=0)
        self.rd1.grid(column=2, row=4)
        self.bt1.grid(column=0, row=14, padx=40, pady=(10, 0))
        self.bt2.grid(column=0, row=0, sticky="E")
        self.bt3.grid(column=0, row=4, sticky='E')
        # self.up_lb.grid(column=0, padx=(0, 15))
        self.root_txt.grid(row=6, column=2)

    def check_server(self):

            status = jstping()

            if status:
                print("ok")
                self.rd0.configure(selectcolor='green')

            else:
                print("down)")
                self.rd0.configure(selectcolor='red')

    def check_updates(self):
        status = lag()
        print(status)
        if status:
            print("updates available")

        else:
            print   ("nothing new!")


if __name__ == "__main__":
    root = Root()
    root.mainloop()
