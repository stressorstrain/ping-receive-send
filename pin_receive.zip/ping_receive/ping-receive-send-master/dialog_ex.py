from tkinter import *

class MyDialog:

    def __init__(self, parent):

        top = self.top = Toplevel(parent)
        top.geometry('220x100')
        top.configure(bg='black')
        self.stats = None

        self.lb0 = Label(top, fg='white', bg='black',   text="Updates available"+"\n"+"Should I retrieve them?")
        self.lb0.grid(column=0, row=0, padx=(45, 0), pady=(10, 10))

        #self.e = Entry(top)
       # self.e.grid(padx=5)

        self.b0 = Button(top, fg='white', bg='black', activebackground='green', text="OK", command=self.ok)
        self.b1 = Button(top, fg='white', bg='black', activebackground='red', text="Nope", command=self.ok)
        self.b0.grid(column=0, row=1, padx=(0, 15))
        self.b1.grid(column=0, row=1, padx=(110, 0))

    def ok(self):
        self.stats = True
        print(self.stats)

        self.top.destroy()


root = Tk()
Button(root, text="Hello!").grid()
root.update()

d = MyDialog(root)

root.wait_window(d.top)